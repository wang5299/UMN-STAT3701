#' dplyr_function_data
               #'
               #' This function to see a file's data frame
               #' @alsosee dplyr(as.data.frame(x,...))
               #' @param infile Path to the input file
               #' @return A data frame of the infile
               #' @import dplyr
               #' @export
               frame_data <- function(infile){
                   as.data.frame(infile)
               }