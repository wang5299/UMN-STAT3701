
           #' This is data to be included in my package
           #'
           #' @author Wang Naichang \email{wang5299@umn.edu}
           #' @references \url{data_blah.com}
           "x" 