#' WangNaichangTools.
#'
#' @name WangNaichangTools
#' @docType package
NULL
