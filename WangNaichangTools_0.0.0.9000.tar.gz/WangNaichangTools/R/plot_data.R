
#' plot_data
           #'
           #' This function loads a file data and then plot it
           #' @alsosee ggplot2(autoplot)
           #' @param infile Path to the input file
           #' @return A plot of the infile
           #' @import ggplot2
           #' @export
outplot_data <- function(infile){
           autoplot(infile)
           }
