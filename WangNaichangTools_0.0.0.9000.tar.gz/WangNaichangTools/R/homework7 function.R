
#' HW7 FUNCTION
           #'
           #' This function from homework 7
           #' @param the file we have
           #' @param function we want to use
           #' @param function the interval it belongs to
           #' @return A data frame of the infile
           #' @import dplyr
           #' @export 
HW7fun<-function(X,FUN,interval,...){
  log1<-function(theta){
    sum(FUN(theta,X))
  }
  result<-optimize(log1,maximum=TRUE,interval)
  return(result$maximum)
}
           