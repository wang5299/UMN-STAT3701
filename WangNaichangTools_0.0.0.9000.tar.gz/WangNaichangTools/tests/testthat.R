library(testthat)
library(WangNaichangTools)

test_check("WangNaichangTools")
